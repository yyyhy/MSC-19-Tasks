#pragma once
#include<stdlib.h>
#include"interferce.h"
//��������
void food() {
	int x, y;
step1:
	x = (int)(18 * rand() / (RAND_MAX + 1.0));
	y = (int)(18 * rand() / (RAND_MAX + 1.0));
	if (map[x][y] == ' ') {
		map[x][y] = 'O ';
	}
	else
		goto step1;
}