#pragma once
#include"snake.h"
#include"interferce.h"
#include"judge.h"
#include"food.h"
void move() {
	int t = length;
	judge();
	if (t == length) {
		map[S[0].x][S[0].y] = ' ';
		S[0].x = S[1].x;
		S[0].y = S[1].y;
		map[S[0].x][S[0].y] = 'X';
		for (int i = 1; i < length - 1; i++) {
			S[i].x = S[i + 1].x;
			S[i].y = S[i + 1].y;
			map[S[i].x][S[i].y] = 'X';
		}
		S[length - 1].x = S[length - 1].x + dx[S[length - 1].dir];
		S[length - 1].y = S[length - 1].y + dy[S[length - 1].dir];

		map[S[length - 1].x][S[length - 1].y] = 'H';
	}
	if (t = length - 1) {
		map[S[length - 2].x][S[length - 2].y] = 'X';
		S[length - 1].x = S[length - 2].x + dx[S[length - 2].dir];
		S[length - 1].y = S[length - 2].y + dy[S[length - 2].dir];
		map[S[length - 1].x][S[length - 1].y] = 'H';
		S[length - 1].dir = S[length - 2].dir;
		food();
	}
}