#pragma once
#include"map.h"
#include"snake.h"
#include<conio.h>
//ת��
void turn() {
	if (_kbhit()) {
		char a = getch();
		switch (a)
		{
		case 119:S[length - 1].dir = 0; break;
		case 100:S[length - 1].dir = 1; break;
		case 115:S[length - 1].dir = 2; break;
		case 97:S[length - 1].dir = 3; break;
		}
	}
}