﻿#pragma once
//这是一条蛇所具备的素质
struct  snake
{
	//🐍长


	//🐍每点坐标
	int x; int y;
	//🐍头运动方向1,2,3,4----->上下左右
	int dir;
}S[100];