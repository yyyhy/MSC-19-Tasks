﻿#pragma once
//地图大小
char map[20][20];
//屏幕更新速度
int sleep=500;
//🐍长
int length=3;
//游戏进行判断
int over = 1;
//🐍动
int dx[4] = { 0,1,0,-1 };
int dy[4] = { -1,0,1,0 };



