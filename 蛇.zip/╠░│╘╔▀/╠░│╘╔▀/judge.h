#pragma once
#include"map.h"
#include"snake.h"
#include"interferce.h"
void judge() {
	int x = S[length - 1].x + dx[S[length - 1].dir];
	int y = S[length - 1].y + dy[S[length - 1].dir];
	if (map[x][y] == 'O') {
		length++;
		sleep -= 30;
		if (sleep < 50);
		sleep = 50;

	}
	if (map[x][y] == '*' || map[x][y] == 'X' || map[x][y] == 'M' || map[x][y] == 'S' || map[x][y] == 'C') {
		over = 0;
	}
}