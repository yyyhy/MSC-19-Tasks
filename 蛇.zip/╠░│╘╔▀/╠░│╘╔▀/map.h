#pragma once
#include"food.h"
#include<stdio.h>
#include"snake.h"
#include"interferce.h"
#include"snake_move.h"
#include"snake_turn.h"
#include<stdlib.h>
#include<windows.h>


//��ͼ����
void mapset() {
	for (int i = 0; i < 20; i++) {
		for (int j = 0; j < 20; j++) {
			map[i][j] = '*';
		}
	}
	for (int p = 1; p < 19; p++) {
		for (int q = 1; q < 19; q++) {
			map[p][q] = ' ';
		}
	}
	//�߳�ʼ��
	for (int w = 0; w < length; w++) {
		S[w].x = 1;
		S[w].y = w + 1;
	}
	S[length - 1].dir = 1;
	map[S[length - 1].x][S[length - 1].y] = 'H';
	for (int l = 0; l < length - 1; l++) {
		map[S[l].x][S[l].y] = 'X';
	}
	//���ӳ�ʼ��
	food();
}
//����ͼ
void mapdraw() {
	for (int i = 0; i < 20; i++) {
		for (int j = 0; j < 20; j++) {
			printf("%c", map[i][j]);
		}
		}
		while (1) {
			Sleep(sleep);
			turn();
			move();
			system("cls");
			for (int i = 0; i < 20; i++) {
				for (int j = 0; j < 20; j++) {
					printf("%c", map[i][j]);
				}
		}
	}
	
	

	
}

