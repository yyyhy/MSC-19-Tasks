

#include<stdio.h>
#include"map.h"
#include"snake_move.h"


int main() {
	mapset();
	mapdraw();
	system("PAUSE");
	return 0;
}